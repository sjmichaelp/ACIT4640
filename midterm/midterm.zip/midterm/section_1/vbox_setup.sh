# s is a shortcut function that makes it shorter and more readable
vbmg () { /mnt/c/Program\ Files/Oracle/VirtualBox/VBoxManage.exe "$@"; }

# If you are using a Mac, you can just use
# vbmg () { VBoxManage "$@"; }

NET_NAME="NETMIDTERM"
VM_NAME="A00945652"
SSH_PORT="12922"
WEB_PORT="12980"

# This function will clean the NAT network and the virtual machine

create_network () {
	vbmg natnetwork add --netname "$NET_NAME" --dhcp off --network "192.168.10.0/24" --port-forward-4 "my_rule:tcp:[127.0.0.1]:$SSH_PORT:[192.168.10.10]:22" --port-forward-4 "my_rule2:tcp:[127.0.0.1]:$WEB_PORT:[192.168.10.10]:80" --enable
}

modify_vm () {
	vbmg modifyvm "MIDTERM4640" --name "$VM_NAME" 
	vbmg modifyvm "$VM_NAME" --nic1 natnetwork --nat-network1 "$NET_NAME"
	vbmg startvm "$VM_NAME"
}

test_midterm_connection() {
#detects when todoapp wakes up
    while /bin/true; do
	ssh midterm -o ConnectTimeout=4 -o StrictHostKeyChecking=no \
	    -o UserKnownHostsFile=/dev/null \
	    -q exit
    	if [ $? -ne 0 ]; then
	    echo "midterm server is not up, sleeping..."
	    sleep 4				        
    	else		
	    break		   
    	fi										
    done
}


echo "Starting script..."

create_network
modify_vm
test_midterm_connection

echo "DONE!"

